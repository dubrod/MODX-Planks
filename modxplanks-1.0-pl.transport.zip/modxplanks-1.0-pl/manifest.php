<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'setup-options' => 'modxplanks-1.0-pl/setup-options.php',
    'enduser_option_merge' => 'yes',
    'enduser_install_action_default' => 'merge',
    'enduser_option_samplecontent' => 'yes',
    'enduser_install_samplecontent_default' => 'yes',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '59e96cfe7df97fece0d7e0c973ab2411',
      'native_key' => '59e96cfe7df97fece0d7e0c973ab2411',
      'filename' => 'xPDOFileVehicle/b8ad5cf95956174f43a911a22d663f07.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => '768df084d2a01e859c48b40f9fb8a24b',
      'native_key' => 1,
      'filename' => 'modChunk/39e6571f0c6a0039828bb6824aed0435.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => '1851a889981a8953ad702f1a80a2bb98',
      'native_key' => 6,
      'filename' => 'modChunk/dc4ff735959808c548cd2b0922363bb7.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => '2aa2a228206f0959035495c8d88670c8',
      'native_key' => 4,
      'filename' => 'modChunk/6d64a6a57bd88afb1b5a53237e07ddc5.vehicle',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => '14e16baaaf9155795bbc471192f70c67',
      'native_key' => 5,
      'filename' => 'modChunk/82822fc31a30fcb1477204a95d0d5bce.vehicle',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modFormCustomizationProfile',
      'guid' => 'dddf614d7106e43e936c3786bbbcc7b3',
      'native_key' => 1,
      'filename' => 'modFormCustomizationProfile/b6dff440b46c769ee0343692fe4de5b2.vehicle',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDocument',
      'guid' => 'd5e973b71a5e703b6f5b6b3da5438913',
      'native_key' => 2,
      'filename' => 'modDocument/f1e80a031b11618627f512ce77f5df06.vehicle',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDocument',
      'guid' => '80b5333f1a469c469c443dd9a532bf2d',
      'native_key' => 3,
      'filename' => 'modDocument/18b139f8bfbb90e93119bb916d4d4435.vehicle',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDocument',
      'guid' => '3623109623c548d3f4ecfcd2e54b2558',
      'native_key' => 4,
      'filename' => 'modDocument/5bb7557057ecede79555d64cffbfc737.vehicle',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDocument',
      'guid' => '6918d809b6efbb37800feb4981a55205',
      'native_key' => 5,
      'filename' => 'modDocument/9c616575d17530b2424db9bac2fbc18e.vehicle',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDocument',
      'guid' => 'f92d2af53a1e75a5d70c3b2eb13d51f6',
      'native_key' => 6,
      'filename' => 'modDocument/f3df5c34b7efe7799a764514829089eb.vehicle',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDocument',
      'guid' => 'bdbd6bc0728eebd974d9f053f2e0028a',
      'native_key' => 7,
      'filename' => 'modDocument/297047bf36c420082bd8c3c79ca88d4d.vehicle',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modTemplate',
      'guid' => 'd7a4eb31dd83083bfbd34b0bbf796798',
      'native_key' => 2,
      'filename' => 'modTemplate/86b2839e5d34737f77b1290333b66689.vehicle',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => '8faa78043e37fa5d4ec2d90a4a56f622',
      'native_key' => '8faa78043e37fa5d4ec2d90a4a56f622',
      'filename' => 'xPDOScriptVehicle/a73e3d71143686828c56568dfcdea67f.vehicle',
    ),
  ),
);